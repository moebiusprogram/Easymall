import React, { Component } from 'react';
import { Header, Button, Popup, Grid, Menu, Icon, Dropdown, Image, Container, Input, Transition, Responsive  } from 'semantic-ui-react'


class Commercial extends Component {
	
	constructor(props) {
		super(props);
		this.handleScroll = this.handleScroll.bind(this);
	}
	
	state = { visible: false }
	
	componentDidMount() {
		window.addEventListener('scroll', this.handleScroll);
	}

	componentWillUnmount() {
		window.removeEventListener('scroll', this.handleScroll);
	}
	
	
	
	handleScroll(event) {
		var heightBound = 1090;
		console.log("Windows Height", heightBound ,' ', window.scrollY);
		if (heightBound < window.scrollY) {
			console.log("paso");
			this.setState({ visible: true })
		} 
	}
  
	
	
  render() {
	  const { visible } = this.state
	  
    return (
	<Container fluid>
		<Grid verticalAlign='middle' >
			<Grid.Row columns={2} >
				<Grid.Column  id='commercial-section-image' mobile={16} tablet={16} computer={8} >
					<Responsive minWidth={Responsive.onlyComputer.minWidth}>
					<Transition visible={visible} animation='fade right' duration={1000}>
						<Image  src='/images/laptop.png' fluid />
					</Transition>
					<Transition visible={visible} animation='fade right' duration={1200}>
						<div style={{ position: 'relative', top: '-32rem', 
							paddingLeft: '25rem', paddingRight: '11rem', fontSize: '96%', color: '#bababc' }}>
							<Header as='h2' content='DISEÑO WEB EXCLUSIVO'
							style={{color: '#bababc'}}/>
							Disfruta de diseños exclusivos para tu imagen corporativa
							llevando el estilo gráfico de tu empresa a otros niveles
							y prepara el camino para el desarrollo del Branding de tu
							empresa y posicionamiento SEO de tu tienda online. Todo esto
							sin ningún cargo extra. ¡Increible! Sólo afíliate y disfruta
							del servicio integral que te ofrece EasyMall
						</div>
					</Transition>
					<Transition visible={visible} animation='fade right' duration={1300}>
						<div style={{ marginTop: '-31.5rem', paddingLeft: '30rem' }}>
							<Button content='Afiliarme' icon='edit' labelPosition='left' />
						</div>
					</Transition>
					</Responsive>
					<Responsive maxWidth={Responsive.onlyTablet.maxWidth}>
						<Image  src='/images/tablet.png' fluid />
					</Responsive>
				</Grid.Column>
				<Grid.Column centered mobile={12} tablet={12} computer={5} style={{ margin:'auto' }}>
					<Header as='h4' style={{ textAlign: 'center', fontWeight: 100, margin: '0'}}>Empresas</Header>
					<Header as='h1' style={{ textAlign: 'center', fontSize: '3rem', marginTop: '0' }}>Potencial Comercial</Header>
					<p>Las bases más importantes del diseño web son nuestro más fiel enfoque a la hora de 
					construir una tienda oficial online para una empresa. Te presentamos nuestras estrategias de desarrollo
					que harán que tu empresa alcance el máximo nivel comercial empresarial económico.</p>
					<Grid textAlign='center'>
						<Grid.Row  columns={5}>
							<Grid.Column >
								<Icon circular inverted color='orange' size='big' name='paint brush'/>
								<div>Diseños</div>
							</Grid.Column>
							<Grid.Column >
								<Icon circular inverted color='orange' size='big' name='hand point up outline'/>
								<div>SEO</div>
							</Grid.Column>
							<Grid.Column >
								<Icon circular inverted color='orange' size='big' name='sync'/>
								<div>Interacción</div>
							</Grid.Column>
							<Grid.Column >
								<Icon circular inverted color='orange' size='big' name='share alternate'/>
								<div>Compartir</div>
							</Grid.Column>
							<Grid.Column >
								<Icon circular inverted color='orange' size='big' name='bullhorn'/>
								<div>Publicidad</div>
							</Grid.Column>
						</Grid.Row>
					</Grid>
				</Grid.Column>
			</Grid.Row>
		</Grid>
	</Container>
    );
  }
}

export default Commercial;
