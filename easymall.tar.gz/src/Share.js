import React, { Component } from 'react';
import { Header, Button, Popup, Grid, Menu, Icon, Dropdown, Image, Container, Input, Transition } from 'semantic-ui-react'


class Share extends Component {
	
	constructor(props) {
		super(props);
		this.handleScroll = this.handleScroll.bind(this);
	}
	
	state = { visible: false }
	
	componentDidMount() {
		window.addEventListener('scroll', this.handleScroll);
	}

	componentWillUnmount() {
		window.removeEventListener('scroll', this.handleScroll);
	}
	
	
	
	handleScroll(event) {
		var heightBound = 1830;
		console.log("Windows Height", heightBound ,' ', window.scrollY);
		if (heightBound < window.scrollY) {
			console.log("paso");
			this.setState({ visible: true })
		} 
	}
  
	
	
  render() {
	  const { visible } = this.state
	  
    return (
	<Container>
		<Grid verticalAlign='middle'>
			<Grid.Row columns={2} style={{ minHeight: '566px' }}>
				<Grid.Column width={8} style={{ color: 'white' }}>
					<Header as='h4' style={{ textAlign: 'center', fontWeight: 100, margin: '0', color:'white'}}>Usuarios</Header>
					<Header as='h1' style={{ textAlign: 'center', fontSize: '3rem', marginTop: '0',color:'white' }}>Al Estilo De Un Mall</Header>
					<p>
					Sabemos que comprar en mercados puede llegar a ser una experiencia insegura
					y desordenada. La nueva plataforma de EasyMall te ofrece la mayor concentración
					de tiendas oficiales de ventas y servicios. Disfruta de la exclusividad,
					seguridad y confort de este destino comercial.
					</p>
					<Grid textAlign='center'>
						<Grid.Row  columns={4}>
							<Grid.Column >
								<Icon circular inverted color='orange' size='big' name='diamond'/>
								<div>Exclusivo</div>
							</Grid.Column>
							<Grid.Column >
								<Icon circular inverted color='orange' size='big' name='heart'/>
								<div>Intuitivo</div>
							</Grid.Column>
							<Grid.Column >
								<Icon circular inverted color='orange' size='big' name='thumbs up outline'/>
								<div>Fácil</div>
							</Grid.Column>
							<Grid.Column >
								<Icon circular inverted color='orange' size='big' name='shield alternate'/>
								<div>Seguro</div>
							</Grid.Column>
						</Grid.Row>
					</Grid>
				</Grid.Column>
				<Grid.Column width={8} >
					<Transition visible={visible} animation='fade left' duration={1000}>
						<div style={{ backgroundColor: 'black', padding: '5rem'}}>
							<Header as='h2' content='Tan Fácil Como Rápido' style={{ color: 'orange' }}/>
							<p style={{color: 'white'}}>
							Disfruta de diseños exclusivos para tu imagen corporativa
							llevando el estilo gráfico de tu empresa a otros niveles
							y prepara el camino para el desarrollo del Branding de tu
							empresa y posicionamiento SEO de tu tienda online. Todo esto
							sin ningún cargo extra. ¡Increible! Sólo afíliate y disfruta
							del servicio integral que te ofrece EasyMall
							</p>
							<Image  src='/images/easymall_flow.png' fluid />
						</div>
					</Transition>
				</Grid.Column>
			</Grid.Row>
		</Grid>
	</Container>
    );
  }
}

export default Share;
